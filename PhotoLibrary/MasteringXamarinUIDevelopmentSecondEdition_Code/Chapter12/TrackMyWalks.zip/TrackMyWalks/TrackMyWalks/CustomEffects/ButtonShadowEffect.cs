﻿using Xamarin.Forms;

namespace TrackMyWalks.CustomEffects
{
    public class ButtonShadowEffect : RoutingEffect
    {
        public ButtonShadowEffect() : base("GeniesoftStudios.ButtonShadowEffect")
        {
        }
    }
}